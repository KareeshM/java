import java.util.Scanner;

class SumOfDigitsDoWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input number from the user
        System.out.print("Enter a number to calculate the sum of its digits: ");
        int num = scanner.nextInt();

        int sum = 0;

        // Calculate sum of digits using a do-while loop
        do {
            sum += num % 10;  // Add the last digit to sum
            num /= 10;         // Remove the last digit
        } while (num != 0);  // Continue until the number becomes 0

        // Display the result
        System.out.println("Sum of the digits is: " + sum);

        scanner.close();
    }
}
