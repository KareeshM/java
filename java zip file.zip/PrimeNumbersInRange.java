import java.util.Scanner;

class PrimeNumbersInRange {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter a number (N) to find all prime numbers up to N: ");
        int N = scanner.nextInt();

        System.out.println("Prime numbers between 1 and " + N + ":");
        
        for (int num = 2; num <= N; num++) { 
            if (isPrime(num)) {
                System.out.print(num + " ");
            }
        }

        scanner.close();
    }

    
    public static boolean isPrime(int num) {
        if (num < 2) return false;

        for (int i = 2; i <= Math.sqrt(num); i++) { // Check divisibility up to sqrt(num)
            if (num % i == 0) {
                return false;
            }
        }
        return true;
    }
}
