import java.util.Scanner;

class PalindromeChecker {
    public static void main(String[] args) {
                Scanner scanner = new Scanner(System.in);
        
        
        System.out.print("Enter a string: ");
        String inputString = scanner.nextLine();
        
                if (isPalindrome(inputString)) {
            System.out.println("The string is a palindrome.");
        } else {
            System.out.println("The string is not a palindrome.");
        }
        
                scanner.close();
    }
    
    
    public static boolean isPalindrome(String str) {
        
        str = str.toLowerCase();
        
                int left = 0;
        int right = str.length() - 1;
        
        while (left < right) {
            
            if (!Character.isLetterOrDigit(str.charAt(left))) {
                left++;
            } else if (!Character.isLetterOrDigit(str.charAt(right))) {
                right--;
            } else {
                               if (str.charAt(left) != str.charAt(right)) {
                    return false;                  }
                left++;
                right--;
            }
        }
        
        return true;      }
}
