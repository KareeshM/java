import java.util.Scanner;

class PrintNumbersDoWhile {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input N from the user
        System.out.print("Enter a number (N): ");
        int N = scanner.nextInt();

        int i = 1; // Initialize counter

        // Print numbers from 1 to N using a do-while loop
        System.out.println("Numbers from 1 to " + N + ":");
        do {
            System.out.print(i + " ");
            i++; // Increment counter
        } while (i <= N);

        scanner.close();
    }
}
