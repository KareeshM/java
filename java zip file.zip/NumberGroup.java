import java.util.Scanner;

class NumberGroup {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter a number: ");
        int num = scanner.nextInt();

        scanner.close(); 

        
        if (num > 50) {
            System.out.println(num + " belongs to the 'Above 50' group.");
        } else if (num >= 40 && num <= 50) {
            System.out.println(num + " belongs to the 'Between 40 and 50' group.");
        } else {
            System.out.println(num + " belongs to the 'Less than 40' group.");
        }
    }
}
