import java.util.Scanner;

class MultiplicationTable {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input N from the user
        System.out.print("Enter a number (N) to print its multiplication table: ");
        int N = scanner.nextInt();

        // Print multiplication table using a for loop
        System.out.println("Multiplication Table of " + N + ":");
        for (int i = 1; i <= 10; i++) {
            System.out.println(N + " x " + i + " = " + (N * i));
        }

        scanner.close();
    }
}
