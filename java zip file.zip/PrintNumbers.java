import java.util.Scanner;

class PrintNumbers {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input N from the user
        System.out.print("Enter a number (N): ");
        int N = scanner.nextInt();

        // Print numbers from 1 to N using a for loop
        System.out.println("Numbers from 1 to " + N + ":");
        for (int i = 1; i <= N; i++) {
            System.out.print(i + " ");
        }

        scanner.close();
    }
}
