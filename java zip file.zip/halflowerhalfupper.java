import java.util.Scanner;

public class HalfLowerHalfUpper {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter a string: ");
        String input = scanner.nextLine();
        
        int length = input.length();
        int halfLength = length / 2;

        
        String firstHalf = input.substring(0, halfLength).toLowerCase();
        String secondHalf = input.substring(halfLength).toUpperCase();

        
        String result = firstHalf + secondHalf;
        System.out.println("Modified String: " + result);

        scanner.close();
    }
}
