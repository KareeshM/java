import java.util.Scanner;
class TwoDArraySc{
public static void main(String[] args){
Scanner obj=new Scanner(System.in);
System.out.println("enter the value of N");
int N=obj.nextInt();
System.out.println("enter the value of M");
int M=obj.nextInt();
int [] [] arr=new int[N][M];
for(int i=0;i<N;i++){
for(int j=0;j<M;j++){
arr[i][j]=obj.nextInt();
}
}
for(int i=0;i<N;i++){
for(int j=0;j<M;j++){
System.out.print(arr[i] [j] +" ");
}
System.out.println(" ");
}
}
}