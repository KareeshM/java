import java.util.Scanner;

class PrintNumbersWhileLoop {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter a number (N): ");
        int N = scanner.nextInt();

        int i = 1; 

        // Print numbers from 1 to N using a while loop
        System.out.println("Numbers from 1 to " + N + ":");
        while (i <= N) {
            System.out.print(i + " ");
            i++; 
        }

        scanner.close();
    }
}
