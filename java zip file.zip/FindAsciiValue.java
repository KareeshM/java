class FindAsciiValue{
     public static void main(String[] args){
	for(int i=0; i<=127;i++){
System.out.println("The ASCII value of"+(char)i+" ="+i);
}
}
}