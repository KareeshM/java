class Main {
    public static void main(String[] args) {
        String str = "Hello World";  
        String vowels = "aeiouAEIOU"; 
        
        
        System.out.print("Vowels in the string: ");
        for (int i = 0; i < str.length(); i++) {
            char ch = str.charAt(i);
            
            
            if (vowels.indexOf(ch) != -1) {
                System.out.print(ch + " ");
            }
        }
    }
}
