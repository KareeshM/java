import java.util.Scanner;

class SumOfDigits {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

               
        System.out.print("Enter a number to calculate the sum of its digits: ");
        int num = scanner.nextInt();

        int sum = 0;

        
        while (num != 0) {
            sum += num % 10;  
            num /= 10;         
        }

        
        System.out.println("Sum of the digits is: " + sum);

        scanner.close();
    }
}
