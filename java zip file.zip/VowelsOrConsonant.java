import java.util.Scanner;

public class VowelOrConsonant {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Prompt user for input
        System.out.print("Enter a character: ");
        char ch = scanner.next().charAt(0);
        scanner.close(); // Close scanner to prevent resource leaks

        // Check if the character is an alphabet
        if (Character.isLetter(ch)) {
            // Convert to lowercase for uniform comparison
            char lowerChar = Character.toLowerCase(ch);
            
            // Check if it's a vowel
            if (lowerChar == 'a' || lowerChar == 'e' || lowerChar == 'i' || lowerChar == 'o' || lowerChar == 'u') {
                System.out.println(ch + " is a vowel.");
            } else {
                System.out.println(ch + " is a consonant.");
            }
        } else {
            System.out.println("Invalid input! Please enter an alphabetic character.");
        }
    }
}
