class ConvertToUpper { 
    public static void main(String[] args) {
        String lowerCaseString = "hello!";
        String upperCaseString = lowerCaseString.toUpperCase();
        
        System.out.println("Original String: " + lowerCaseString);
        System.out.println("Uppercase String: " + upperCaseString);
    }
}
