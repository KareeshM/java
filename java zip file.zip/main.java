class Main {
public static void main(String[] args) {
        String str = "India";  
        
        for (int i = 0; i < str.length(); i++) {
            System.out.println(str.charAt(i));
        }
    }
}
