class DataTypesExample {
    public static void main(String[] args) {
        
        byte byteVar = 127;       
        short shortVar = 32000;   
        int intVar = 100000;      
        long longVar = 10000000000L; 

        
        float floatVar = 3.14f;   
        double doubleVar = 3.1415926535; 

        
        char charVar = 'A';       

        
        boolean boolVar = true;   

       
        System.out.println("Byte value: " + byteVar);
        System.out.println("Short value: " + shortVar);
        System.out.println("Int value: " + intVar);
        System.out.println("Long value: " + longVar);
        System.out.println("Float value: " + floatVar);
        System.out.println("Double value: " + doubleVar);
        System.out.println("Char value: " + charVar);
        System.out.println("Boolean value: " + boolVar);
    }
}
