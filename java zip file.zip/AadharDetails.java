import java.util.Scanner;

class AadharDetails {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter your Name: ");
        String name = scanner.nextLine();

        System.out.print("Enter your Aadhar Number (XXXX-XXXX-XXXX): ");
        String aadharNumber = scanner.nextLine();

        System.out.print("Enter your Date of Birth (DD-MM-YYYY): ");
        String dob = scanner.nextLine();

        System.out.print("Enter your Address: ");
        String address = scanner.nextLine();

        System.out.println("\n----- Aadhar Card Details -----");
        System.out.println("Name         : " + name);
        System.out.println("Aadhar No.   : " + aadharNumber);
        System.out.println("Date of Birth: " + dob);
        System.out.println("Address      : " + address);
        System.out.println("------------------------------");

        scanner.close();
    }
}
