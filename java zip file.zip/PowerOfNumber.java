import java.util.Scanner;

 class PowerOfNumber {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        // Input base and exponent from the user
        System.out.print("Enter the base: ");
        int base = scanner.nextInt();
        System.out.print("Enter the exponent: ");
        int exponent = scanner.nextInt();

        int result = 1;
        int count = 1;

        // Calculate power using a do-while loop
        do {
            result *= base;  // Multiply result by base in each iteration
            count++;         // Increment the counter
        } while (count <= exponent);

        // Display the result
        System.out.println(base + " raised to the power of " + exponent + " is: " + result);

        scanner.close();
    }
}
