import java.util.Scanner;
public class ToCharArray{
public static void main(string[] args){
Scanner input=new Scanner(system.in);
string s=input.nextLine();
char[] ca=s.toCharArray();
System.out.println(ca);
for(ca:ch){
System.out.println(ch);

}
}