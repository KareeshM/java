import java.util.Scanner;

class LogicalOperators {
    public static void main(String[] args) {
        Scanner scanner = new Scanner(System.in);

        
        System.out.print("Enter first boolean value (true/false): ");
        boolean a = scanner.nextBoolean();

        System.out.print("Enter second boolean value (true/false): ");
        boolean b = scanner.nextBoolean();

        
        System.out.println("\n----- Logical Operators Output -----");
        System.out.println("a && b  : " + (a && b));  // Logical AND
        System.out.println("a || b  : " + (a || b));  // Logical OR
        System.out.println("!a      : " + (!a));      // Logical NOT on 'a'
        System.out.println("!b      : " + (!b));      // Logical NOT on 'b'

        scanner.close();
    }
}
